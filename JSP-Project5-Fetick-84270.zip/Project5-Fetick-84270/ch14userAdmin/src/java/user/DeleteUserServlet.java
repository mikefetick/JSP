package user;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

import business.User;
import data.UserDB;
import java.util.ArrayList;

public class DeleteUserServlet extends HttpServlet
{

    protected void doGet(HttpServletRequest request, 
            HttpServletResponse response) 
            throws ServletException, IOException
    {
        String emailAddress = request.getParameter("emailAddress");
        
        // Exercise 14-2.9 - Mike Fetick 84270
        // Add code that deletes the user that corresponds with the email address from the database
        ArrayList<User> usersFromDB = UserDB.selectUsers();
        User thisUser = null;
        User thatUser = null;
        String thisEmailAddress;
        for (int i=0; i<usersFromDB.size(); i++){
            thisUser = usersFromDB.get(i);
            thisEmailAddress = thisUser.getEmailAddress();
            if (thisEmailAddress.equals(emailAddress)) {
                thatUser = usersFromDB.get(i);
            }
        }
        
        UserDB.delete(thatUser);

        UserDB.selectUsers();
        
        String url = "/displayUsers";
        RequestDispatcher dispatcher =
              getServletContext().getRequestDispatcher(url);
        dispatcher.forward(request, response);
    }
}
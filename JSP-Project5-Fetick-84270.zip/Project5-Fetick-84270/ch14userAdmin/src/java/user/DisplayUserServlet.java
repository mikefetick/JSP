package user;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

import business.User;
import data.UserDB;

public class DisplayUserServlet extends HttpServlet
{
    protected void doGet(HttpServletRequest request, 
            HttpServletResponse response) 
            throws ServletException, IOException
    {
        String emailAddress = request.getParameter("emailAddress");
        // Exercise 14-2.6 - Mike Fetick 84270
        // Get the User object
        if(emailAddress != null && emailAddress.length() > 0){    
            if (UserDB.emailExists(emailAddress)) {
                User user = null;
                user = UserDB.selectUser(emailAddress);

                HttpSession session = request.getSession();
                // Set the User object as a session attribute
                request.getSession().setAttribute("user", user);            
            }
        }

        String url = "/user.jsp";
        RequestDispatcher dispatcher =
              getServletContext().getRequestDispatcher(url);
        dispatcher.forward(request, response);
    }
}
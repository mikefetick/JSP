package user;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

import java.util.ArrayList;
import business.User;
import data.UserDB;

public class DisplayUsersServlet extends HttpServlet
{
    protected void doGet(HttpServletRequest request, 
            HttpServletResponse response) 
            throws ServletException, IOException
    {
        // Exercise 14-2.4 - Mike Fetick 84270
        // Get an ArrayList of User objects from the database
        ArrayList<User> usersFromDB = UserDB.selectUsers();
        
        HttpSession session = request.getSession();
        // Exercise 14-2.4 - Mike Fetick 84270
        // Set the ArrayList of User objects as a session attribute
        User thisUser = null;
        for (int i=0; i<usersFromDB.size(); i++){
            thisUser = usersFromDB.get(i);
        }
        if(thisUser != null){
            request.setAttribute("user", thisUser);
            request.getSession().setAttribute("users", usersFromDB);
        }else{
            request.setAttribute("outOfUsers", "There are no users.");
        }
        // Exercise 14-2.4 - Mike Fetick 84270
        // Forward the request to display the list of users
        String url = "/users.jsp";
        RequestDispatcher dispatcher =
              getServletContext().getRequestDispatcher(url);
        dispatcher.forward(request, response);
    }
    
    protected void doPost(HttpServletRequest request,
            HttpServletResponse response) 
            throws ServletException, IOException
    {
        doGet(request, response);
    }    
}
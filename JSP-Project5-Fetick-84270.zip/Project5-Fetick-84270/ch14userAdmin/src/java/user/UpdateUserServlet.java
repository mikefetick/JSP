package user;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

import business.User;
import data.UserDB;

public class UpdateUserServlet extends HttpServlet
{

    protected void doPost(HttpServletRequest request, 
            HttpServletResponse response) 
            throws ServletException, IOException
    {
        String firstName = request.getParameter("firstName");
        String lastName = request.getParameter("lastName");

        HttpSession session = request.getSession();
        // Exercise 14-2.8 - Mike Fetick 84270
        // Add code that gets the User object from the session and updates the database
        User thatUser = null;
        thatUser = (User) session.getAttribute("user");
        thatUser.setFirstName(firstName);
        thatUser.setLastName(lastName);
        session.setAttribute("user", thatUser);            

        UserDB.update(thatUser);

        UserDB.selectUsers();
        
        String url = "/displayUsers";
        RequestDispatcher dispatcher =
              getServletContext().getRequestDispatcher(url);
        dispatcher.forward(request, response);
    }
}
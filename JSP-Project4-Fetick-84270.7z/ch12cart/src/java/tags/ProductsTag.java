package tags;

import java.io.IOException;
import java.util.*;
import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.*;

import business.*;
/**
 * @author Michael Fetick 84270
 */
public class ProductsTag extends BodyTagSupport {

    private ArrayList<LineItem> lineItems;
    private Iterator iterator;
    private LineItem item;
    
    public int doStartTag() throws JspException {
/* Exercise 12-2.5 We want the products attribute of the session. */
        Product cart = (Product) pageContext.findAttribute("products");
        lineItems = cart.getItems();
        if (lineItems.size() <= 0)
        {
            return SKIP_BODY;
        }
        else
        {
            return EVAL_BODY_BUFFERED;
        }
    }
    
    public void doInitBody() throws JspException
    {
        iterator = lineItems.iterator();
        if (iterator.hasNext())
        {
            item = (LineItem) iterator.next();
            this.setItemAttributes(item);
        }
    }
    
    private void setItemAttributes(LineItem item)
    {
        Product p = item.getProduct();
        pageContext.setAttribute(
                "productCode", p.getCode());
        pageContext.setAttribute(
                "productDescription", p.getDescription());
        pageContext.setAttribute(
                "productPrice", p.getPriceCurrencyFormat());
        pageContext.setAttribute(
                "quantity", new Integer(item.getQuantity()));
        pageContext.setAttribute(
                "total", item.getTotalCurrencyFormat());
    }
    
    public int doAfterBody() throws JspException
    {
        try
        {
            if (iterator.hasNext())
            {
                item = (LineItem) iterator.next();
                this.setItemAttributes(item);
                return EVAL_BODY_AGAIN;
            }
            else
            {
                JspWriter out = bodyContent.getEnclosingWriter();
                bodyContent.writeOut(out);
                return SKIP_BODY;
            }
        }
        catch(IOException ioe)
        {
            System.err.println("error in doAfterBody " + ioe.getMessage());
            return SKIP_BODY;
        }
    }
    
}
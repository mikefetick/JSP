package tags;

import javax.servlet.jsp.*;
import javax.servlet.jsp.tagext.*;
import java.io.*;

public class IfEmptyMarkTag extends TagSupport
{
    private String field;
    /* Exercise 12-1.13 Modified the color to green
       but were using the IfEmptyMarkSimpleTag for our in-class exercise
       so the color is modified there too.*/
    private String color = "green";

    public void setField(String field)
    {
        this.field = field;
    }

    public void setColor(String color)
    {
        this.color = color;
    }

    public int doStartTag() throws JspException
    {
        try
        {
            JspWriter out = pageContext.getOut();
            if (field == null || field.length() == 0)
            {
                out.print("<font color=" + color + "> *</font>");
            }
        }
        catch(IOException ioe)
        {
            ioe.printStackTrace();
        }
        return SKIP_BODY;
    }
}
package tags;

import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.JspException;
import javax.servlet.jsp.tagext.JspFragment;
import javax.servlet.jsp.tagext.SimpleTagSupport;

/* @author 84270 */
public class IfEmptyMarkSimpleTag extends SimpleTagSupport {

    private String field;
    /* Exercise 12-1.13 Modified the color to green  */
    private String color = "green";

    public void setField(String field)
    {
        this.field = field;
    }

    public void setColor(String color)
    {
        this.color = color;
    }

    @Override
    public void doTag() throws JspException {
        JspWriter out = getJspContext().getOut();
        
        try {
            // TODO: insert code to write html before writing the body content.
            JspWriter simpleOut = this.getJspContext().getOut();
            if (field == null || field.length() == 0)
            {
                JspFragment body = this.getJspBody();
                simpleOut.write("<font color=\"" + color + "\">");
                body.invoke(simpleOut);
                simpleOut.write("</font>");
            }
            // Removed JspFragment f = getJspBody().
 
        } catch (java.io.IOException ex) {
            throw new JspException("Error in IfEmptyMarkSimpleTag tag", ex);
        }
    }
}

package tags;

import javax.servlet.jsp.*;
import javax.servlet.jsp.tagext.*;
import java.io.*;
import java.util.*;
import java.text.DateFormat;

public class CurrentDateTag extends TagSupport
{
    public int doStartTag() throws JspException
    {
        Date currentDate = new Date();
        /* Exercise 12-1.11 Modify this class to use the LONG format  */
        DateFormat shortDate = DateFormat.getDateInstance(DateFormat.LONG);
        String currentDateFormatted = shortDate.format(currentDate);

        try
        {
            JspWriter out = pageContext.getOut();
            out.print(currentDateFormatted);
        }
        catch (IOException ioe)
        {
            ioe.printStackTrace();
        }
        return SKIP_BODY;
    }
}
package tags;

import javax.servlet.jsp.*;
import javax.servlet.jsp.tagext.*;
import java.io.*;
import java.util.*;
import java.text.DateFormat;

public class CurrentTimeTag extends TagSupport
{
    public int doStartTag() throws JspException
    {
        Date currentTime = new Date();
        /* Exercise 12-1.11 Modify this class to use the LONG format  */
        DateFormat shortTime = DateFormat.getTimeInstance(DateFormat.LONG);
        String currentTimeFormatted = shortTime.format(currentTime);

        try
        {
            JspWriter out = pageContext.getOut();
            out.print(currentTimeFormatted);
        }
        catch (IOException ioe)
        {
            ioe.printStackTrace();
        }
        return SKIP_BODY;
    }
}